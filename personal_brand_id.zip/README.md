# personal_brand_id
This is the Anas Latique personal brand identity
